/**
 */
package lang.m2.wffjzc.tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lang.m2.wffjzc.Bbbb;
import lang.m2.wffjzc.Ffff;
import lang.m2.wffjzc.WffjzcFactory;
import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

/**
 * <!-- begin-user-doc --> A sample utility for the '<em><b>wffjzc</b></em>'
 * package. <!-- end-user-doc -->
 * 
 * @generated
 */
public class Montest {

	
	static final String SPACES="                                                                           ";

	public static void main(String[] args) {

		faire();
         
		defaire();
	}

	
	private String printFfff(Ffff f, int depth){
		String result = SPACES.substring(0,depth*3) + f.getId()+"\n";
		List<Ffff> subfs =  f.getSubFs();
		depth++;
		for (Ffff ffff : subfs) {
			result += printFfff(ffff,depth);
		}
		return result;
	}
	
	
	
	private String readFile(String path) {
		File fil = new File(path);
		StringBuffer buffer = new StringBuffer();
		try {
			InputStream in = new FileInputStream(fil);
			try {
				InputStreamReader inR = new InputStreamReader(in);
				BufferedReader buf = new BufferedReader(inR);
				String line;
				while ((line = buf.readLine()) != null)
					buffer.append(line).append(";");
			} finally {
				in.close();
			}
		} catch (IOException e) {
			System.err.println("no file " + path);
			return "";
		}
		return buffer.toString();
	}

	private void writeFile(String path, String content) {
		if (path != null && !path.isEmpty() && content != null
				&& !content.isEmpty()) {
			File fil = new File(path);
			FileWriter fw;
			try {
				fw = new FileWriter(fil, false);
				fw.write(content);
				fw.close();
			} catch (IOException e) {
				// e.printStackTrace();
				System.err.println("SDBV_WF  "+e.toString());
			}
		} else
			System.err.println("nothing to save (" + path + ")");
	}
	
	
	public static void defaire() {
		Montest montest = new Montest();
		Bbbb root = (Bbbb) montest.load("C:\\workspaces\\mintel416\\lang.m2.wffjzc.tests\\mesmodeles\\monpremier.wffjzc");
	    String result = montest.printFfff(root.getFs().get(0), 0);
	    System.out.println(result);
	    montest.writeFile("C:\\workspaces\\mintel416\\lang.m2.wffjzc.tests\\mesmodeles\\monpremier.txt", result);
	}

	
	
	public static void faire() {
		Montest montest = new Montest();
		Bbbb root = montest.createModel();
		File file = new File(
				"C:\\workspaces\\mintel416\\lang.m2.wffjzc.tests\\mesmodeles\\monpremier.wffjzc");
		Resource resource = null;
		URI uri = URI.createFileURI(file.getAbsolutePath());

		try {
			montest.save(root, uri);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Bbbb createModel() {
		Bbbb root = WffjzcFactory.eINSTANCE.createBbbb();

		Ffff f = WffjzcFactory.eINSTANCE.createFfff();
		f.setId("toto");
		root.getFs().add(f);
		
		Ffff f1 = WffjzcFactory.eINSTANCE.createFfff();
		f1.setId("toto1");
		f.getSubFs().add(f1);
		
		Ffff f2 = WffjzcFactory.eINSTANCE.createFfff();
		f2.setId("toto2");
		f1.getSubFs().add(f2);
	
		return root;
	}


	private Resource save(EObject toSave, URI uri) throws IOException {
		new File(uri.toFileString()).delete();
		Resource resource = new XMIResourceFactoryImpl().createResource(uri);
		resource.getContents().add(toSave);
		Map<String, String> options = new HashMap<String, String>();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(options);
		return resource;
	}


	public EObject load(String filename) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet
				.getResourceFactoryRegistry()
				.getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION,
						new XMIResourceFactoryImpl());

		resourceSet.getPackageRegistry().put(WffjzcPackage.eNS_URI,
				WffjzcPackage.eINSTANCE);

		File file = new File(filename);
		Resource resource = null;
		URI uri = URI.createFileURI(file.getAbsolutePath());
		try {
			resource = resourceSet.getResource(uri, true);
			System.out.println("Loaded " + uri);

		} catch (RuntimeException exception) {
			System.out.println("Problem loading " + uri);
			exception.printStackTrace();
		}
		return resource == null ? null : resource.getContents().get(0);
	}


} // WffjzcExample
