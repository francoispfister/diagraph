/**
 */
package lang.m2.wffjzc.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import lang.m2.wffjzc.EClass1;
import lang.m2.wffjzc.WffjzcFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>EClass1</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class EClass1Test extends TestCase {

	/**
	 * The fixture for this EClass1 test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass1 fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(EClass1Test.class);
	}

	/**
	 * Constructs a new EClass1 test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass1Test(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this EClass1 test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(EClass1 fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this EClass1 test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass1 getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WffjzcFactory.eINSTANCE.createEClass1());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //EClass1Test
