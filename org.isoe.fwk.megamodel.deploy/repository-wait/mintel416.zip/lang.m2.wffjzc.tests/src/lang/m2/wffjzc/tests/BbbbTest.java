/**
 */
package lang.m2.wffjzc.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import lang.m2.wffjzc.Bbbb;
import lang.m2.wffjzc.WffjzcFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Bbbb</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class BbbbTest extends TestCase {

	/**
	 * The fixture for this Bbbb test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Bbbb fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(BbbbTest.class);
	}

	/**
	 * Constructs a new Bbbb test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BbbbTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Bbbb test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Bbbb fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Bbbb test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Bbbb getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WffjzcFactory.eINSTANCE.createBbbb());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //BbbbTest
