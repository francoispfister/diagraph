/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see lang.m2.wffjzc.WffjzcFactory
 * @model kind="package"
 * @generated
 */
public interface WffjzcPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "wffjzc";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://wffjzc";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "_wffjzc";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WffjzcPackage eINSTANCE = lang.m2.wffjzc.impl.WffjzcPackageImpl.init();

	/**
	 * The meta object id for the '{@link lang.m2.wffjzc.impl.BbbbImpl <em>Bbbb</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see lang.m2.wffjzc.impl.BbbbImpl
	 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getBbbb()
	 * @generated
	 */
	int BBBB = 0;

	/**
	 * The feature id for the '<em><b>Fs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BBBB__FS = 0;

	/**
	 * The feature id for the '<em><b>EReference0</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BBBB__EREFERENCE0 = 1;

	/**
	 * The number of structural features of the '<em>Bbbb</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BBBB_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link lang.m2.wffjzc.impl.FfffImpl <em>Ffff</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see lang.m2.wffjzc.impl.FfffImpl
	 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getFfff()
	 * @generated
	 */
	int FFFF = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FFFF__ID = 0;

	/**
	 * The feature id for the '<em><b>Sub Fs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FFFF__SUB_FS = 1;

	/**
	 * The number of structural features of the '<em>Ffff</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FFFF_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link lang.m2.wffjzc.impl.EClass0Impl <em>EClass0</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see lang.m2.wffjzc.impl.EClass0Impl
	 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getEClass0()
	 * @generated
	 */
	int ECLASS0 = 2;

	/**
	 * The feature id for the '<em><b>Ee1s</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ECLASS0__EE1S = 0;

	/**
	 * The feature id for the '<em><b>Foo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ECLASS0__FOO = 1;

	/**
	 * The number of structural features of the '<em>EClass0</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ECLASS0_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link lang.m2.wffjzc.impl.EClass1Impl <em>EClass1</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see lang.m2.wffjzc.impl.EClass1Impl
	 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getEClass1()
	 * @generated
	 */
	int ECLASS1 = 3;

	/**
	 * The feature id for the '<em><b>Bar</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ECLASS1__BAR = 0;

	/**
	 * The number of structural features of the '<em>EClass1</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ECLASS1_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link lang.m2.wffjzc.BasicFlowTransformationType <em>Basic Flow Transformation Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see lang.m2.wffjzc.BasicFlowTransformationType
	 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getBasicFlowTransformationType()
	 * @generated
	 */
	int BASIC_FLOW_TRANSFORMATION_TYPE = 4;


	/**
	 * Returns the meta object for class '{@link lang.m2.wffjzc.Bbbb <em>Bbbb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bbbb</em>'.
	 * @see lang.m2.wffjzc.Bbbb
	 * @generated
	 */
	EClass getBbbb();

	/**
	 * Returns the meta object for the containment reference list '{@link lang.m2.wffjzc.Bbbb#getFs <em>Fs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fs</em>'.
	 * @see lang.m2.wffjzc.Bbbb#getFs()
	 * @see #getBbbb()
	 * @generated
	 */
	EReference getBbbb_Fs();

	/**
	 * Returns the meta object for the containment reference '{@link lang.m2.wffjzc.Bbbb#getEReference0 <em>EReference0</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>EReference0</em>'.
	 * @see lang.m2.wffjzc.Bbbb#getEReference0()
	 * @see #getBbbb()
	 * @generated
	 */
	EReference getBbbb_EReference0();

	/**
	 * Returns the meta object for class '{@link lang.m2.wffjzc.Ffff <em>Ffff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ffff</em>'.
	 * @see lang.m2.wffjzc.Ffff
	 * @generated
	 */
	EClass getFfff();

	/**
	 * Returns the meta object for the attribute '{@link lang.m2.wffjzc.Ffff#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see lang.m2.wffjzc.Ffff#getId()
	 * @see #getFfff()
	 * @generated
	 */
	EAttribute getFfff_Id();

	/**
	 * Returns the meta object for the containment reference list '{@link lang.m2.wffjzc.Ffff#getSubFs <em>Sub Fs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Fs</em>'.
	 * @see lang.m2.wffjzc.Ffff#getSubFs()
	 * @see #getFfff()
	 * @generated
	 */
	EReference getFfff_SubFs();

	/**
	 * Returns the meta object for class '{@link lang.m2.wffjzc.EClass0 <em>EClass0</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>EClass0</em>'.
	 * @see lang.m2.wffjzc.EClass0
	 * @generated
	 */
	EClass getEClass0();

	/**
	 * Returns the meta object for the containment reference list '{@link lang.m2.wffjzc.EClass0#getEe1s <em>Ee1s</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ee1s</em>'.
	 * @see lang.m2.wffjzc.EClass0#getEe1s()
	 * @see #getEClass0()
	 * @generated
	 */
	EReference getEClass0_Ee1s();

	/**
	 * Returns the meta object for the attribute '{@link lang.m2.wffjzc.EClass0#getFoo <em>Foo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Foo</em>'.
	 * @see lang.m2.wffjzc.EClass0#getFoo()
	 * @see #getEClass0()
	 * @generated
	 */
	EAttribute getEClass0_Foo();

	/**
	 * Returns the meta object for class '{@link lang.m2.wffjzc.EClass1 <em>EClass1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>EClass1</em>'.
	 * @see lang.m2.wffjzc.EClass1
	 * @generated
	 */
	EClass getEClass1();

	/**
	 * Returns the meta object for the attribute '{@link lang.m2.wffjzc.EClass1#getBar <em>Bar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bar</em>'.
	 * @see lang.m2.wffjzc.EClass1#getBar()
	 * @see #getEClass1()
	 * @generated
	 */
	EAttribute getEClass1_Bar();

	/**
	 * Returns the meta object for enum '{@link lang.m2.wffjzc.BasicFlowTransformationType <em>Basic Flow Transformation Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Basic Flow Transformation Type</em>'.
	 * @see lang.m2.wffjzc.BasicFlowTransformationType
	 * @generated
	 */
	EEnum getBasicFlowTransformationType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	WffjzcFactory getWffjzcFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link lang.m2.wffjzc.impl.BbbbImpl <em>Bbbb</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see lang.m2.wffjzc.impl.BbbbImpl
		 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getBbbb()
		 * @generated
		 */
		EClass BBBB = eINSTANCE.getBbbb();

		/**
		 * The meta object literal for the '<em><b>Fs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BBBB__FS = eINSTANCE.getBbbb_Fs();

		/**
		 * The meta object literal for the '<em><b>EReference0</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BBBB__EREFERENCE0 = eINSTANCE.getBbbb_EReference0();

		/**
		 * The meta object literal for the '{@link lang.m2.wffjzc.impl.FfffImpl <em>Ffff</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see lang.m2.wffjzc.impl.FfffImpl
		 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getFfff()
		 * @generated
		 */
		EClass FFFF = eINSTANCE.getFfff();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FFFF__ID = eINSTANCE.getFfff_Id();

		/**
		 * The meta object literal for the '<em><b>Sub Fs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FFFF__SUB_FS = eINSTANCE.getFfff_SubFs();

		/**
		 * The meta object literal for the '{@link lang.m2.wffjzc.impl.EClass0Impl <em>EClass0</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see lang.m2.wffjzc.impl.EClass0Impl
		 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getEClass0()
		 * @generated
		 */
		EClass ECLASS0 = eINSTANCE.getEClass0();

		/**
		 * The meta object literal for the '<em><b>Ee1s</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ECLASS0__EE1S = eINSTANCE.getEClass0_Ee1s();

		/**
		 * The meta object literal for the '<em><b>Foo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ECLASS0__FOO = eINSTANCE.getEClass0_Foo();

		/**
		 * The meta object literal for the '{@link lang.m2.wffjzc.impl.EClass1Impl <em>EClass1</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see lang.m2.wffjzc.impl.EClass1Impl
		 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getEClass1()
		 * @generated
		 */
		EClass ECLASS1 = eINSTANCE.getEClass1();

		/**
		 * The meta object literal for the '<em><b>Bar</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ECLASS1__BAR = eINSTANCE.getEClass1_Bar();

		/**
		 * The meta object literal for the '{@link lang.m2.wffjzc.BasicFlowTransformationType <em>Basic Flow Transformation Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see lang.m2.wffjzc.BasicFlowTransformationType
		 * @see lang.m2.wffjzc.impl.WffjzcPackageImpl#getBasicFlowTransformationType()
		 * @generated
		 */
		EEnum BASIC_FLOW_TRANSFORMATION_TYPE = eINSTANCE.getBasicFlowTransformationType();

	}

} //WffjzcPackage
