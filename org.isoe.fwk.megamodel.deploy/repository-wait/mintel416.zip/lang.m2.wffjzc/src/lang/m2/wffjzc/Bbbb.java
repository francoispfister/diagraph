/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bbbb</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.Bbbb#getFs <em>Fs</em>}</li>
 *   <li>{@link lang.m2.wffjzc.Bbbb#getEReference0 <em>EReference0</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.wffjzc.WffjzcPackage#getBbbb()
 * @model annotation="diagraph node='_' pov='_'"
 * @generated
 */
public interface Bbbb extends EObject {
	/**
	 * Returns the value of the '<em><b>Fs</b></em>' containment reference list.
	 * The list contents are of type {@link lang.m2.wffjzc.Ffff}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fs</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fs</em>' containment reference list.
	 * @see lang.m2.wffjzc.WffjzcPackage#getBbbb_Fs()
	 * @model containment="true"
	 * @generated
	 */
	EList<Ffff> getFs();

	/**
	 * Returns the value of the '<em><b>EReference0</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>EReference0</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>EReference0</em>' containment reference.
	 * @see #setEReference0(EClass0)
	 * @see lang.m2.wffjzc.WffjzcPackage#getBbbb_EReference0()
	 * @model containment="true"
	 * @generated
	 */
	EClass0 getEReference0();

	/**
	 * Sets the value of the '{@link lang.m2.wffjzc.Bbbb#getEReference0 <em>EReference0</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>EReference0</em>' containment reference.
	 * @see #getEReference0()
	 * @generated
	 */
	void setEReference0(EClass0 value);

} // Bbbb
