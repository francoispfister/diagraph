/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ffff</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.Ffff#getId <em>Id</em>}</li>
 *   <li>{@link lang.m2.wffjzc.Ffff#getSubFs <em>Sub Fs</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.wffjzc.WffjzcPackage#getFfff()
 * @model annotation="diagraph node='_' label\075id='_' cont\075Bbbb.fs='_' kref\075subFs='_'"
 * @generated
 */
public interface Ffff extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see lang.m2.wffjzc.WffjzcPackage#getFfff_Id()
	 * @model
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link lang.m2.wffjzc.Ffff#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Sub Fs</b></em>' containment reference list.
	 * The list contents are of type {@link lang.m2.wffjzc.Ffff}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Fs</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Fs</em>' containment reference list.
	 * @see lang.m2.wffjzc.WffjzcPackage#getFfff_SubFs()
	 * @model containment="true"
	 * @generated
	 */
	EList<Ffff> getSubFs();

} // Ffff
