/**
 */
package lang.m2.wffjzc.impl;

import java.util.Collection;

import lang.m2.wffjzc.EClass0;
import lang.m2.wffjzc.EClass1;
import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>EClass0</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.impl.EClass0Impl#getEe1s <em>Ee1s</em>}</li>
 *   <li>{@link lang.m2.wffjzc.impl.EClass0Impl#getFoo <em>Foo</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EClass0Impl extends EObjectImpl implements EClass0 {
	/**
	 * The cached value of the '{@link #getEe1s() <em>Ee1s</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEe1s()
	 * @generated
	 * @ordered
	 */
	protected EList<EClass1> ee1s;

	/**
	 * The default value of the '{@link #getFoo() <em>Foo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoo()
	 * @generated
	 * @ordered
	 */
	protected static final String FOO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFoo() <em>Foo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoo()
	 * @generated
	 * @ordered
	 */
	protected String foo = FOO_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass0Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WffjzcPackage.Literals.ECLASS0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EClass1> getEe1s() {
		if (ee1s == null) {
			ee1s = new EObjectContainmentEList<EClass1>(EClass1.class, this, WffjzcPackage.ECLASS0__EE1S);
		}
		return ee1s;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFoo() {
		return foo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFoo(String newFoo) {
		String oldFoo = foo;
		foo = newFoo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WffjzcPackage.ECLASS0__FOO, oldFoo, foo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WffjzcPackage.ECLASS0__EE1S:
				return ((InternalEList<?>)getEe1s()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WffjzcPackage.ECLASS0__EE1S:
				return getEe1s();
			case WffjzcPackage.ECLASS0__FOO:
				return getFoo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WffjzcPackage.ECLASS0__EE1S:
				getEe1s().clear();
				getEe1s().addAll((Collection<? extends EClass1>)newValue);
				return;
			case WffjzcPackage.ECLASS0__FOO:
				setFoo((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WffjzcPackage.ECLASS0__EE1S:
				getEe1s().clear();
				return;
			case WffjzcPackage.ECLASS0__FOO:
				setFoo(FOO_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WffjzcPackage.ECLASS0__EE1S:
				return ee1s != null && !ee1s.isEmpty();
			case WffjzcPackage.ECLASS0__FOO:
				return FOO_EDEFAULT == null ? foo != null : !FOO_EDEFAULT.equals(foo);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (foo: ");
		result.append(foo);
		result.append(')');
		return result.toString();
	}

} //EClass0Impl
