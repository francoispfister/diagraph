/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EClass1</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.EClass1#getBar <em>Bar</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.wffjzc.WffjzcPackage#getEClass1()
 * @model annotation="diagraph node='_' label\075bar='_'"
 * @generated
 */
public interface EClass1 extends EObject {
	/**
	 * Returns the value of the '<em><b>Bar</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bar</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bar</em>' attribute.
	 * @see #setBar(String)
	 * @see lang.m2.wffjzc.WffjzcPackage#getEClass1_Bar()
	 * @model
	 * @generated
	 */
	String getBar();

	/**
	 * Sets the value of the '{@link lang.m2.wffjzc.EClass1#getBar <em>Bar</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bar</em>' attribute.
	 * @see #getBar()
	 * @generated
	 */
	void setBar(String value);

} // EClass1
