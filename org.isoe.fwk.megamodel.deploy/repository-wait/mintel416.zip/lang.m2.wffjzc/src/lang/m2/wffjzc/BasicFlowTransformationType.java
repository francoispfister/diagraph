/**
 */
package lang.m2.wffjzc;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Basic Flow Transformation Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see lang.m2.wffjzc.WffjzcPackage#getBasicFlowTransformationType()
 * @model
 * @generated
 */
public enum BasicFlowTransformationType implements Enumerator {
	/**
	 * The '<em><b>EEnum Literal0</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EENUM_LITERAL0_VALUE
	 * @generated
	 * @ordered
	 */
	EENUM_LITERAL0(0, "EEnumLiteral0", "EEnumLiteral0"),

	/**
	 * The '<em><b>Transiform</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRANSIFORM_VALUE
	 * @generated
	 * @ordered
	 */
	TRANSIFORM(1, "Transiform", "Transiform"),

	/**
	 * The '<em><b>Check Verify Validate</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CHECK_VERIFY_VALIDATE_VALUE
	 * @generated
	 * @ordered
	 */
	CHECK_VERIFY_VALIDATE(2, "Check_Verify_Validate", "Check_Verify_Validate"),

	/**
	 * The '<em><b>Control</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONTROL_VALUE
	 * @generated
	 * @ordered
	 */
	CONTROL(3, "Control", "Control"),

	/**
	 * The '<em><b>Decide</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DECIDE_VALUE
	 * @generated
	 * @ordered
	 */
	DECIDE(4, "Decide", "Decide"),

	/**
	 * The '<em><b>Measure</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEASURE_VALUE
	 * @generated
	 * @ordered
	 */
	MEASURE(5, "Measure", "Measure"),

	/**
	 * The '<em><b>Store</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STORE_VALUE
	 * @generated
	 * @ordered
	 */
	STORE(6, "Store", "Store"),

	/**
	 * The '<em><b>Wait</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WAIT_VALUE
	 * @generated
	 * @ordered
	 */
	WAIT(7, "Wait", "Wait");

	/**
	 * The '<em><b>EEnum Literal0</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>EEnum Literal0</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EENUM_LITERAL0
	 * @model name="EEnumLiteral0"
	 * @generated
	 * @ordered
	 */
	public static final int EENUM_LITERAL0_VALUE = 0;

	/**
	 * The '<em><b>Transiform</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Transiform</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRANSIFORM
	 * @model name="Transiform"
	 * @generated
	 * @ordered
	 */
	public static final int TRANSIFORM_VALUE = 1;

	/**
	 * The '<em><b>Check Verify Validate</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Check Verify Validate</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CHECK_VERIFY_VALIDATE
	 * @model name="Check_Verify_Validate"
	 * @generated
	 * @ordered
	 */
	public static final int CHECK_VERIFY_VALIDATE_VALUE = 2;

	/**
	 * The '<em><b>Control</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Control</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONTROL
	 * @model name="Control"
	 * @generated
	 * @ordered
	 */
	public static final int CONTROL_VALUE = 3;

	/**
	 * The '<em><b>Decide</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Decide</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DECIDE
	 * @model name="Decide"
	 * @generated
	 * @ordered
	 */
	public static final int DECIDE_VALUE = 4;

	/**
	 * The '<em><b>Measure</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Measure</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MEASURE
	 * @model name="Measure"
	 * @generated
	 * @ordered
	 */
	public static final int MEASURE_VALUE = 5;

	/**
	 * The '<em><b>Store</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Store</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STORE
	 * @model name="Store"
	 * @generated
	 * @ordered
	 */
	public static final int STORE_VALUE = 6;

	/**
	 * The '<em><b>Wait</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Wait</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #WAIT
	 * @model name="Wait"
	 * @generated
	 * @ordered
	 */
	public static final int WAIT_VALUE = 7;

	/**
	 * An array of all the '<em><b>Basic Flow Transformation Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final BasicFlowTransformationType[] VALUES_ARRAY =
		new BasicFlowTransformationType[] {
			EENUM_LITERAL0,
			TRANSIFORM,
			CHECK_VERIFY_VALIDATE,
			CONTROL,
			DECIDE,
			MEASURE,
			STORE,
			WAIT,
		};

	/**
	 * A public read-only list of all the '<em><b>Basic Flow Transformation Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<BasicFlowTransformationType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Basic Flow Transformation Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BasicFlowTransformationType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			BasicFlowTransformationType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Basic Flow Transformation Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BasicFlowTransformationType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			BasicFlowTransformationType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Basic Flow Transformation Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BasicFlowTransformationType get(int value) {
		switch (value) {
			case EENUM_LITERAL0_VALUE: return EENUM_LITERAL0;
			case TRANSIFORM_VALUE: return TRANSIFORM;
			case CHECK_VERIFY_VALIDATE_VALUE: return CHECK_VERIFY_VALIDATE;
			case CONTROL_VALUE: return CONTROL;
			case DECIDE_VALUE: return DECIDE;
			case MEASURE_VALUE: return MEASURE;
			case STORE_VALUE: return STORE;
			case WAIT_VALUE: return WAIT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private BasicFlowTransformationType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //BasicFlowTransformationType
