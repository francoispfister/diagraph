/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see lang.m2.wffjzc.WffjzcPackage
 * @generated
 */
public interface WffjzcFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WffjzcFactory eINSTANCE = lang.m2.wffjzc.impl.WffjzcFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Bbbb</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Bbbb</em>'.
	 * @generated
	 */
	Bbbb createBbbb();

	/**
	 * Returns a new object of class '<em>Ffff</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ffff</em>'.
	 * @generated
	 */
	Ffff createFfff();

	/**
	 * Returns a new object of class '<em>EClass0</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EClass0</em>'.
	 * @generated
	 */
	EClass0 createEClass0();

	/**
	 * Returns a new object of class '<em>EClass1</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EClass1</em>'.
	 * @generated
	 */
	EClass1 createEClass1();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	WffjzcPackage getWffjzcPackage();

} //WffjzcFactory
