/**
 */
package lang.m2.wffjzc.impl;

import java.util.Collection;

import lang.m2.wffjzc.Bbbb;
import lang.m2.wffjzc.EClass0;
import lang.m2.wffjzc.Ffff;
import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bbbb</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.impl.BbbbImpl#getFs <em>Fs</em>}</li>
 *   <li>{@link lang.m2.wffjzc.impl.BbbbImpl#getEReference0 <em>EReference0</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BbbbImpl extends EObjectImpl implements Bbbb {
	/**
	 * The cached value of the '{@link #getFs() <em>Fs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFs()
	 * @generated
	 * @ordered
	 */
	protected EList<Ffff> fs;

	/**
	 * The cached value of the '{@link #getEReference0() <em>EReference0</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEReference0()
	 * @generated
	 * @ordered
	 */
	protected EClass0 eReference0;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BbbbImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WffjzcPackage.Literals.BBBB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Ffff> getFs() {
		if (fs == null) {
			fs = new EObjectContainmentEList<Ffff>(Ffff.class, this, WffjzcPackage.BBBB__FS);
		}
		return fs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass0 getEReference0() {
		return eReference0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEReference0(EClass0 newEReference0, NotificationChain msgs) {
		EClass0 oldEReference0 = eReference0;
		eReference0 = newEReference0;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, WffjzcPackage.BBBB__EREFERENCE0, oldEReference0, newEReference0);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEReference0(EClass0 newEReference0) {
		if (newEReference0 != eReference0) {
			NotificationChain msgs = null;
			if (eReference0 != null)
				msgs = ((InternalEObject)eReference0).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - WffjzcPackage.BBBB__EREFERENCE0, null, msgs);
			if (newEReference0 != null)
				msgs = ((InternalEObject)newEReference0).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - WffjzcPackage.BBBB__EREFERENCE0, null, msgs);
			msgs = basicSetEReference0(newEReference0, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WffjzcPackage.BBBB__EREFERENCE0, newEReference0, newEReference0));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WffjzcPackage.BBBB__FS:
				return ((InternalEList<?>)getFs()).basicRemove(otherEnd, msgs);
			case WffjzcPackage.BBBB__EREFERENCE0:
				return basicSetEReference0(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WffjzcPackage.BBBB__FS:
				return getFs();
			case WffjzcPackage.BBBB__EREFERENCE0:
				return getEReference0();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WffjzcPackage.BBBB__FS:
				getFs().clear();
				getFs().addAll((Collection<? extends Ffff>)newValue);
				return;
			case WffjzcPackage.BBBB__EREFERENCE0:
				setEReference0((EClass0)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WffjzcPackage.BBBB__FS:
				getFs().clear();
				return;
			case WffjzcPackage.BBBB__EREFERENCE0:
				setEReference0((EClass0)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WffjzcPackage.BBBB__FS:
				return fs != null && !fs.isEmpty();
			case WffjzcPackage.BBBB__EREFERENCE0:
				return eReference0 != null;
		}
		return super.eIsSet(featureID);
	}

} //BbbbImpl
