/**
 */
package lang.m2.wffjzc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EClass0</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.wffjzc.EClass0#getEe1s <em>Ee1s</em>}</li>
 *   <li>{@link lang.m2.wffjzc.EClass0#getFoo <em>Foo</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.wffjzc.WffjzcPackage#getEClass0()
 * @model annotation="diagraph node='_' label\075foo='_' cref\075ee1s='_'"
 * @generated
 */
public interface EClass0 extends EObject {
	/**
	 * Returns the value of the '<em><b>Ee1s</b></em>' containment reference list.
	 * The list contents are of type {@link lang.m2.wffjzc.EClass1}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ee1s</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ee1s</em>' containment reference list.
	 * @see lang.m2.wffjzc.WffjzcPackage#getEClass0_Ee1s()
	 * @model containment="true"
	 * @generated
	 */
	EList<EClass1> getEe1s();

	/**
	 * Returns the value of the '<em><b>Foo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Foo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Foo</em>' attribute.
	 * @see #setFoo(String)
	 * @see lang.m2.wffjzc.WffjzcPackage#getEClass0_Foo()
	 * @model
	 * @generated
	 */
	String getFoo();

	/**
	 * Sets the value of the '{@link lang.m2.wffjzc.EClass0#getFoo <em>Foo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Foo</em>' attribute.
	 * @see #getFoo()
	 * @generated
	 */
	void setFoo(String value);

} // EClass0
