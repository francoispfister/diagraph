/**
 */
package lang.m2.wffjzc.impl;

import lang.m2.wffjzc.BasicFlowTransformationType;
import lang.m2.wffjzc.Bbbb;
import lang.m2.wffjzc.EClass0;
import lang.m2.wffjzc.EClass1;
import lang.m2.wffjzc.Ffff;
import lang.m2.wffjzc.WffjzcFactory;
import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WffjzcPackageImpl extends EPackageImpl implements WffjzcPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bbbbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ffffEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eClass0EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eClass1EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum basicFlowTransformationTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see lang.m2.wffjzc.WffjzcPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private WffjzcPackageImpl() {
		super(eNS_URI, WffjzcFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link WffjzcPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static WffjzcPackage init() {
		if (isInited) return (WffjzcPackage)EPackage.Registry.INSTANCE.getEPackage(WffjzcPackage.eNS_URI);

		// Obtain or create and register package
		WffjzcPackageImpl theWffjzcPackage = (WffjzcPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof WffjzcPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new WffjzcPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theWffjzcPackage.createPackageContents();

		// Initialize created meta-data
		theWffjzcPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theWffjzcPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(WffjzcPackage.eNS_URI, theWffjzcPackage);
		return theWffjzcPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBbbb() {
		return bbbbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBbbb_Fs() {
		return (EReference)bbbbEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBbbb_EReference0() {
		return (EReference)bbbbEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFfff() {
		return ffffEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFfff_Id() {
		return (EAttribute)ffffEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFfff_SubFs() {
		return (EReference)ffffEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEClass0() {
		return eClass0EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEClass0_Ee1s() {
		return (EReference)eClass0EClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEClass0_Foo() {
		return (EAttribute)eClass0EClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEClass1() {
		return eClass1EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEClass1_Bar() {
		return (EAttribute)eClass1EClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getBasicFlowTransformationType() {
		return basicFlowTransformationTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WffjzcFactory getWffjzcFactory() {
		return (WffjzcFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		bbbbEClass = createEClass(BBBB);
		createEReference(bbbbEClass, BBBB__FS);
		createEReference(bbbbEClass, BBBB__EREFERENCE0);

		ffffEClass = createEClass(FFFF);
		createEAttribute(ffffEClass, FFFF__ID);
		createEReference(ffffEClass, FFFF__SUB_FS);

		eClass0EClass = createEClass(ECLASS0);
		createEReference(eClass0EClass, ECLASS0__EE1S);
		createEAttribute(eClass0EClass, ECLASS0__FOO);

		eClass1EClass = createEClass(ECLASS1);
		createEAttribute(eClass1EClass, ECLASS1__BAR);

		// Create enums
		basicFlowTransformationTypeEEnum = createEEnum(BASIC_FLOW_TRANSFORMATION_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(bbbbEClass, Bbbb.class, "Bbbb", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBbbb_Fs(), this.getFfff(), null, "fs", null, 0, -1, Bbbb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBbbb_EReference0(), this.getEClass0(), null, "EReference0", null, 0, 1, Bbbb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ffffEClass, Ffff.class, "Ffff", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFfff_Id(), ecorePackage.getEString(), "id", null, 0, 1, Ffff.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFfff_SubFs(), this.getFfff(), null, "subFs", null, 0, -1, Ffff.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(eClass0EClass, EClass0.class, "EClass0", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEClass0_Ee1s(), this.getEClass1(), null, "ee1s", null, 0, -1, EClass0.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEClass0_Foo(), ecorePackage.getEString(), "foo", null, 0, 1, EClass0.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(eClass1EClass, EClass1.class, "EClass1", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEClass1_Bar(), ecorePackage.getEString(), "bar", null, 0, 1, EClass1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.class, "BasicFlowTransformationType");
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.EENUM_LITERAL0);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.TRANSIFORM);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.CHECK_VERIFY_VALIDATE);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.CONTROL);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.DECIDE);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.MEASURE);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.STORE);
		addEEnumLiteral(basicFlowTransformationTypeEEnum, BasicFlowTransformationType.WAIT);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// diagraph
		createDiagraphAnnotations();
	}

	/**
	 * Initializes the annotations for <b>diagraph</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createDiagraphAnnotations() {
		String source = "diagraph";		
		addAnnotation
		  (bbbbEClass, 
		   source, 
		   new String[] {
			 "node", "_",
			 "pov", "_"
		   });		
		addAnnotation
		  (ffffEClass, 
		   source, 
		   new String[] {
			 "node", "_",
			 "label=id", "_",
			 "cont=Bbbb.fs", "_",
			 "kref=subFs", "_"
		   });		
		addAnnotation
		  (eClass0EClass, 
		   source, 
		   new String[] {
			 "node", "_",
			 "label=foo", "_",
			 "cref=ee1s", "_"
		   });		
		addAnnotation
		  (eClass1EClass, 
		   source, 
		   new String[] {
			 "node", "_",
			 "label=bar", "_"
		   });
	}

} //WffjzcPackageImpl
