/**
 * 
 */
package org.eclipse.gmf.runtime.diagram.ui.outline.actions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.operations.OperationHistoryFactory;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EStructuralFeature.Setting;
import org.eclipse.emf.ecore.util.ECrossReferenceAdapter;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.commands.core.command.AbstractTransactionalCommand;
import org.eclipse.gmf.runtime.notation.NotationPackage;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;

public abstract class AbstractAction extends Action {
	/**
	 * 
	 */
	protected final StructuredViewer viewer;
	protected final TransactionalEditingDomain domain;

	protected AbstractAction(String text, TransactionalEditingDomain domain,
			StructuredViewer viewer) {
		super(text);
		this.domain = domain;
		this.viewer = viewer;
	}

	@Override
	public void run() {
		ISelection selection = viewer.getSelection();
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection structSel = (IStructuredSelection) selection;
			final EObject firstElement = (EObject) structSel.getFirstElement();
			ECrossReferenceAdapter crossReferenceAdapter = ECrossReferenceAdapter
					.getCrossReferenceAdapter(firstElement);
			Collection<Setting> inverseReferences = crossReferenceAdapter
					.getInverseReferences(firstElement);
			View view = null;
			for (Setting setting : inverseReferences) {
				EStructuralFeature structuralFeature = setting
						.getEStructuralFeature();
				if (NotationPackage.Literals.VIEW__ELEMENT
						.equals(structuralFeature)) {
					view = (View) setting.getEObject();
				}
			}
			command = getCommand(firstElement, view);
			if (command.canExecute()) {
				AbstractTransactionalCommand abstractTransactionalCommand = new AbstractTransactionalCommand(
						domain, "", new ArrayList<IFile>()) {

					@Override
					protected CommandResult doExecuteWithResult(
							IProgressMonitor monitor, IAdaptable info)
							throws ExecutionException {
						return AbstractAction.this.doExecuteWithResult(
								firstElement, monitor, info);
					}

				};
				try {
					OperationHistoryFactory.getOperationHistory()
							.execute(abstractTransactionalCommand,
									new NullProgressMonitor(), null);
				} catch (ExecutionException e) {
					e.printStackTrace();
				}
			}
		}
	}

	protected abstract Command getCommand(EObject element, View view);

	private Command command = null;

	protected CommandResult doExecuteWithResult(EObject element,
			IProgressMonitor monitor, IAdaptable info) {
		if (command != null && command.canExecute()) {
			command.execute();
			return CommandResult.newOKCommandResult();
		} else {
			return CommandResult.newCancelledCommandResult();
		}
	}

	static <T> Collection<T> addAll(Collection<T> col, Iterator<T> iterator) {
		while (iterator.hasNext()) {
			col.add(iterator.next());
		}
		return col;
	}
}