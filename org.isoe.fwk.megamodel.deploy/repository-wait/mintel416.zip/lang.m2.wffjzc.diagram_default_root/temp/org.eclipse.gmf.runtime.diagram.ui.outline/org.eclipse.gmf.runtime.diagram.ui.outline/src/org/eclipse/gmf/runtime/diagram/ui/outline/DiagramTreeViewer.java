/**
 * 
 */
package org.eclipse.gmf.runtime.diagram.ui.outline;

import java.lang.reflect.Field;

import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jface.util.SafeRunnable;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.PageBookView;

final class DiagramTreeViewer extends TreeViewer {
	DiagramTreeViewer(Composite parent, int style) {
		super(parent, style);
	}

	/**
	 * Notifies any selection changed listeners that the viewer's selection has
	 * changed. Only listeners registered at the time this method is called are
	 * notified.
	 * 
	 * @param event
	 *            a selection changed event
	 * 
	 * @see TreeViewer#selectionChanged
	 */
	protected void fireSelectionChanged(final SelectionChangedEvent event) {
		Object[] listeners = getPrivateField(this, ListenerList.class,
				"selectionChangedListeners").getListeners();
		for (int i = 0; i < listeners.length; ++i) {
			final ISelectionChangedListener l = (ISelectionChangedListener) listeners[i];
			SafeRunnable.run(new SafeRunnable() {
				public void run() {
					Class<? extends ISelectionChangedListener> clazz = l
							.getClass();
					if (clazz.getName()
							.startsWith(PageBookView.class.getName())) {
						l.selectionChanged(event);
					} else {
						l.selectionChanged(event);
					}
				}
			});
		}
	}

	static private <TYPE> TYPE getPrivateField(Object obj, Class<TYPE> type,
			String fieldName) {
		try {
			Class<?> clazz = obj.getClass();
			Field field = getField(clazz, fieldName);
			if (null != field && type.isAssignableFrom(field.getType())) {
				field.setAccessible(true);
				@SuppressWarnings("unchecked")
				TYPE ret = (TYPE) field.get(obj);
				return ret;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Field getField(Class<?> clazz, String fieldName) {
		Field ret = null;
		if (null != clazz)
			try {
				ret = clazz.getDeclaredField(fieldName);
			} catch (NoSuchFieldException e) {
				ret = getField(clazz.getSuperclass(), fieldName);
				if (null == ret) {
					Class<?>[] interfaces = clazz.getInterfaces();
					for (Class<?> interfaze : interfaces) {
						ret = getField(interfaze, fieldName);
						if (null != ret) {
							break;
						}
					}
				}
			}
		return ret;
	}
}