/**
 * 
 */
package org.eclipse.gmf.runtime.diagram.ui.outline.actions;

import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.command.PasteFromClipboardCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.StructuredViewer;

public class PasteAction extends AbstractAction {
	public PasteAction(TransactionalEditingDomain domain, StructuredViewer viewer) {
		super("Paste", domain, viewer);
	}

	protected Command getCommand(EObject element, View view) {
		return PasteFromClipboardCommand.create(domain,
				element, null);
	}
}