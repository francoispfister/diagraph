/**
 * 
 */
package org.eclipse.gmf.runtime.diagram.ui.outline.actions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.command.CopyToClipboardCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;

public class CopyAction extends AbstractAction {

	public CopyAction(TransactionalEditingDomain domain,
			StructuredViewer viewer) {
		super("Copy", domain, viewer);
	}

	protected Command getCommand(EObject element, View view) {
		@SuppressWarnings("unchecked")
		Collection<EObject> list = addAll(new ArrayList<EObject>(),
				(Iterator<EObject>)((IStructuredSelection) viewer.getSelection()).iterator());
		return CopyToClipboardCommand.create(domain, list);
	}
}