package lang.m2.wffjzc.diagram_default_root.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class WffjzcElementTypes {

	/**
	 * @generated
	 */
	private WffjzcElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map<IElementType, ENamedElement> elements;

	/**
	 * @generated
	 */
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().getItemProvidersAdapterFactory());

	/**
	 * @generated
	 */
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType Bbbb_79 = getElementType("lang.m2.wffjzc.diagram_default_root.Bbbb_79"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_1001 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_1001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType EClass0_1002 = getElementType("lang.m2.wffjzc.diagram_default_root.EClass0_1002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2001 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2002 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2003 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2004 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2005 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2005"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2006 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2006"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2007 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Ffff_2008 = getElementType("lang.m2.wffjzc.diagram_default_root.Ffff_2008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType EClass1_2009 = getElementType("lang.m2.wffjzc.diagram_default_root.EClass1_2009"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(Bbbb_79, WffjzcPackage.eINSTANCE.getBbbb());

			elements.put(Ffff_1001, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(EClass0_1002, WffjzcPackage.eINSTANCE.getEClass0());

			elements.put(Ffff_2001, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2002, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2003, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2004, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2005, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2006, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2007, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(Ffff_2008, WffjzcPackage.eINSTANCE.getFfff());

			elements.put(EClass1_2009, WffjzcPackage.eINSTANCE.getEClass1());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(Bbbb_79);
			KNOWN_ELEMENT_TYPES.add(Ffff_1001);
			KNOWN_ELEMENT_TYPES.add(EClass0_1002);
			KNOWN_ELEMENT_TYPES.add(Ffff_2001);
			KNOWN_ELEMENT_TYPES.add(Ffff_2002);
			KNOWN_ELEMENT_TYPES.add(Ffff_2003);
			KNOWN_ELEMENT_TYPES.add(Ffff_2004);
			KNOWN_ELEMENT_TYPES.add(Ffff_2005);
			KNOWN_ELEMENT_TYPES.add(Ffff_2006);
			KNOWN_ELEMENT_TYPES.add(Ffff_2007);
			KNOWN_ELEMENT_TYPES.add(Ffff_2008);
			KNOWN_ELEMENT_TYPES.add(EClass1_2009);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
			return Bbbb_79;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return Ffff_1001;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return EClass0_1002;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return Ffff_2001;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return Ffff_2002;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return Ffff_2003;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return Ffff_2004;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return Ffff_2005;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return Ffff_2006;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return Ffff_2007;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return Ffff_2008;
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return EClass1_2009;
		}
		return null;
	}

	/**
	 * @generated
	 */
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(
			elementTypeImages) {

		/**
		 * @generated
		 */
		@Override
		public boolean isKnownElementType(IElementType elementType) {
			return lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
					.isKnownElementType(elementType);
		}

		/**
		 * @generated
		 */
		@Override
		public IElementType getElementTypeForVisualId(int visualID) {
			return lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
					.getElementType(visualID);
		}

		/**
		 * @generated
		 */
		@Override
		public ENamedElement getDefiningNamedElement(
				IAdaptable elementTypeAdapter) {
			return lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
					.getElement(elementTypeAdapter);
		}
	};

}
