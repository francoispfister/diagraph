package lang.m2.wffjzc.diagram_default_root.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String WffjzcCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String WffjzcDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String WffjzcNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String WffjzcDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String WffjzcElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String Default1Group_title;

	/**
	 * @generated
	 */
	public static String EClass02CreationTool_title;

	/**
	 * @generated
	 */
	public static String EClass02CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Ffff4CreationTool_title;

	/**
	 * @generated
	 */
	public static String Ffff4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String EClass15CreationTool_title;

	/**
	 * @generated
	 */
	public static String EClass15CreationTool_desc;

	/**
	 * @generated
	 */
	public static String FfffSubFsEditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs2EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs3EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs4EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs5EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs6EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs7EditPart_title;

	/**
	 * @generated
	 */
	public static String FfffSubFs8EditPart_title;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String WffjzcModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String WffjzcModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
