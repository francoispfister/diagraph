package lang.m2.wffjzc.diagram_default_root.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class WffjzcEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getVisualID(view)) {

			case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffIdEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffIdEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0FooEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0FooEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId2EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId2EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId3EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId3EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId4EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId4EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId5EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId5EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId6EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId6EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId7EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId7EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId8EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId8EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId9EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId9EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1BarEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1BarEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFsEditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFsEditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs2EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs2EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs3EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs3EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs4EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs4EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs5EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs5EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs6EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs6EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs7EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs7EditPart(
						view);

			case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs8EditPart.VISUAL_ID:
				return new lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs8EditPart(
						view);
			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
