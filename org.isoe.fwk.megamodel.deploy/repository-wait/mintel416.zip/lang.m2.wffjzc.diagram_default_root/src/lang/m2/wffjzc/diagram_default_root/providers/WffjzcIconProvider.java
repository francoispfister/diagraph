package lang.m2.wffjzc.diagram_default_root.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class WffjzcIconProvider extends DefaultElementTypeIconProvider
		implements IIconProvider {

	/**
	 * @generated
	 */
	public WffjzcIconProvider() {
		super(
				lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.TYPED_INSTANCE);
	}

}
