package lang.m2.wffjzc.diagram_default_root.part;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.PaletteSeparator;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class WffjzcPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createDefault1Group());
	}

	/**
	 * Creates "default" palette tool group
	 * @generated
	 */
	private PaletteContainer createDefault1Group() {
		PaletteGroup paletteContainer = new PaletteGroup(
				lang.m2.wffjzc.diagram_default_root.part.Messages.Default1Group_title);
		paletteContainer.setId("createDefault1Group"); //$NON-NLS-1$
		paletteContainer.add(new PaletteSeparator());
		paletteContainer.add(createEClass02CreationTool());
		paletteContainer.add(new PaletteSeparator());
		paletteContainer.add(createFfff4CreationTool());
		paletteContainer.add(createEClass15CreationTool());
		paletteContainer.add(new PaletteSeparator());
		paletteContainer.add(new PaletteSeparator());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createEClass02CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				lang.m2.wffjzc.diagram_default_root.part.Messages.EClass02CreationTool_title,
				lang.m2.wffjzc.diagram_default_root.part.Messages.EClass02CreationTool_desc,
				Collections
						.singletonList(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass0_1002));
		entry.setId("createEClass02CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.findImageDescriptor("/lang.m2.wffjzc/icons/EClass0.gif")); //$NON-NLS-1$
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createFfff4CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(9);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2001);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2002);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2003);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2004);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2005);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2006);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2007);
		types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2008);
		NodeToolEntry entry = new NodeToolEntry(
				lang.m2.wffjzc.diagram_default_root.part.Messages.Ffff4CreationTool_title,
				lang.m2.wffjzc.diagram_default_root.part.Messages.Ffff4CreationTool_desc,
				types);
		entry.setId("createFfff4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.findImageDescriptor("/lang.m2.wffjzc/icons/Ffff.gif")); //$NON-NLS-1$
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createEClass15CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				lang.m2.wffjzc.diagram_default_root.part.Messages.EClass15CreationTool_title,
				lang.m2.wffjzc.diagram_default_root.part.Messages.EClass15CreationTool_desc,
				Collections
						.singletonList(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass1_2009));
		entry.setId("createEClass15CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.findImageDescriptor("/lang.m2.wffjzc/icons/EClass1.gif")); //$NON-NLS-1$
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List<IElementType> elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
