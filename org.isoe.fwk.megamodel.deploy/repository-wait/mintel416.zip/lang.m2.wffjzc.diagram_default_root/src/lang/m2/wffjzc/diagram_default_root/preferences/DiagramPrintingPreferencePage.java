package lang.m2.wffjzc.diagram_default_root.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	 * @generated
	 */
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
