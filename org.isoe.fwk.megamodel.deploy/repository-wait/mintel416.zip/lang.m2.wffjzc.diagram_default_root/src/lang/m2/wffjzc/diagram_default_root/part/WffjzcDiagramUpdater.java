package lang.m2.wffjzc.diagram_default_root.part;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import lang.m2.wffjzc.Bbbb;
import lang.m2.wffjzc.EClass0;
import lang.m2.wffjzc.EClass1;
import lang.m2.wffjzc.Ffff;

import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class WffjzcDiagramUpdater {

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getSemanticChildren(
			View view) {
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
			return getBbbb_79SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getEClass0_1002SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFsEditPart.VISUAL_ID:
			return getFfffSubFs_5001SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs2EditPart.VISUAL_ID:
			return getFfffSubFs_5002SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs3EditPart.VISUAL_ID:
			return getFfffSubFs_5003SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs4EditPart.VISUAL_ID:
			return getFfffSubFs_5004SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs5EditPart.VISUAL_ID:
			return getFfffSubFs_5005SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs6EditPart.VISUAL_ID:
			return getFfffSubFs_5006SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs7EditPart.VISUAL_ID:
			return getFfffSubFs_5007SemanticChildren(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs8EditPart.VISUAL_ID:
			return getFfffSubFs_5008SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getBbbb_79SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		Bbbb modelElement = (Bbbb) view.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		{
			EClass0 childElement = modelElement.getEReference0();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getEClass0_1002SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		EClass0 modelElement = (EClass0) view.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEe1s().iterator(); it.hasNext();) {
			EClass1 childElement = (EClass1) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5002SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5005SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5006SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5007SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> getFfffSubFs_5008SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Ffff modelElement = (Ffff) containerView.getElement();
		LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor> result = new LinkedList<lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor>();
		for (Iterator<?> it = modelElement.getSubFs().iterator(); it.hasNext();) {
			Ffff childElement = (Ffff) it.next();
			int visualID = lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID) {
				result.add(new lang.m2.wffjzc.diagram_default_root.part.WffjzcNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getContainedLinks(
			View view) {
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
			return getBbbb_79ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return getFfff_1001ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getEClass0_1002ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return getFfff_2001ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return getFfff_2002ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return getFfff_2003ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return getFfff_2004ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return getFfff_2005ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return getFfff_2006ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return getFfff_2007ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return getFfff_2008ContainedLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return getEClass1_2009ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getIncomingLinks(
			View view) {
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return getFfff_1001IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getEClass0_1002IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return getFfff_2001IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return getFfff_2002IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return getFfff_2003IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return getFfff_2004IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return getFfff_2005IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return getFfff_2006IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return getFfff_2007IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return getFfff_2008IncomingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return getEClass1_2009IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getOutgoingLinks(
			View view) {
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return getFfff_1001OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getEClass0_1002OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return getFfff_2001OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return getFfff_2002OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return getFfff_2003OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return getFfff_2004OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return getFfff_2005OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return getFfff_2006OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return getFfff_2007OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return getFfff_2008OutgoingLinks(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return getEClass1_2009OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getBbbb_79ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_1001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass0_1002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2005ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2007ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2008ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass1_2009ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_1001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass0_1002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2004IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2005IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2006IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2007IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2008IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass1_2009IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_1001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass0_1002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2005OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2006OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2007OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getFfff_2008OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<lang.m2.wffjzc.diagram_default_root.part.WffjzcLinkDescriptor> getEClass1_2009OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

}
