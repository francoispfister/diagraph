package lang.m2.wffjzc.diagram_default_root.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class WffjzcBaseEditHelper extends GeneratedEditHelperBase {

}
