package lang.m2.wffjzc.diagram_default_root.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	 * @generated
	 */
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		lang.m2.wffjzc.diagram_default_root.preferences.DiagramGeneralPreferencePage
				.initDefaults(store);
		lang.m2.wffjzc.diagram_default_root.preferences.DiagramAppearancePreferencePage
				.initDefaults(store);
		lang.m2.wffjzc.diagram_default_root.preferences.DiagramConnectionsPreferencePage
				.initDefaults(store);
		lang.m2.wffjzc.diagram_default_root.preferences.DiagramPrintingPreferencePage
				.initDefaults(store);
		lang.m2.wffjzc.diagram_default_root.preferences.DiagramRulersAndGridPreferencePage
				.initDefaults(store);

	}

	/**
	 * @generated
	 */
	protected IPreferenceStore getPreferenceStore() {
		return lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance().getPreferenceStore();
	}
}
