package lang.m2.wffjzc.diagram_default_root.edit.policies;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

/**
 * @generated
 */
public class BbbbItemSemanticEditPolicy
		extends
		lang.m2.wffjzc.diagram_default_root.edit.policies.WffjzcBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public BbbbItemSemanticEditPolicy() {
		super(
				lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Bbbb_79);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001 == req
				.getElementType()) {
			return getGEFWrapper(new lang.m2.wffjzc.diagram_default_root.edit.commands.FfffCreateCommand(
					req));
		}
		if (lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass0_1002 == req
				.getElementType()) {
			return getGEFWrapper(new lang.m2.wffjzc.diagram_default_root.edit.commands.EClass0CreateCommand(
					req));
		}
		return super.getCreateCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost())
				.getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	 * @generated
	 */
	private static class DuplicateAnythingCommand extends
			DuplicateEObjectsCommand {

		/**
		 * @generated
		 */
		public DuplicateAnythingCommand(
				TransactionalEditingDomain editingDomain,
				DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req
					.getElementsToBeDuplicated(), req
					.getAllDuplicatedElementsMap());
		}

	}

}
