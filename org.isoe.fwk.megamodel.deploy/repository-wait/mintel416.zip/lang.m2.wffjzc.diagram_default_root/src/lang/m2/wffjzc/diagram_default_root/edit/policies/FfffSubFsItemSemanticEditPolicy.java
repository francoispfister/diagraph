package lang.m2.wffjzc.diagram_default_root.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class FfffSubFsItemSemanticEditPolicy
		extends
		lang.m2.wffjzc.diagram_default_root.edit.policies.WffjzcBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public FfffSubFsItemSemanticEditPolicy() {
		super(
				lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2001 == req
				.getElementType()) {
			return getGEFWrapper(new lang.m2.wffjzc.diagram_default_root.edit.commands.Ffff2CreateCommand(
					req));
		}
		return super.getCreateCommand(req);
	}

}
