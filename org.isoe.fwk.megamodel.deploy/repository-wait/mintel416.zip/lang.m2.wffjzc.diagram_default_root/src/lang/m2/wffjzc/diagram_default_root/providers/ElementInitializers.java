package lang.m2.wffjzc.diagram_default_root.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance().getElementInitializers();
		if (cached == null) {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().setElementInitializers(
							cached = new ElementInitializers());
		}
		return cached;
	}
}
