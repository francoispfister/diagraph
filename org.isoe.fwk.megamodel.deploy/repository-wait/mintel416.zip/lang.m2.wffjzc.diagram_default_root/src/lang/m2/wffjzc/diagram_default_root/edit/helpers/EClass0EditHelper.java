package lang.m2.wffjzc.diagram_default_root.edit.helpers;

/**
 * @generated
 */
public class EClass0EditHelper extends
		lang.m2.wffjzc.diagram_default_root.edit.helpers.WffjzcBaseEditHelper {
}
