package lang.m2.wffjzc.diagram_default_root.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class FfffSubFs5ItemSemanticEditPolicy
		extends
		lang.m2.wffjzc.diagram_default_root.edit.policies.WffjzcBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public FfffSubFs5ItemSemanticEditPolicy() {
		super(
				lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2004);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2005 == req
				.getElementType()) {
			return getGEFWrapper(new lang.m2.wffjzc.diagram_default_root.edit.commands.Ffff6CreateCommand(
					req));
		}
		return super.getCreateCommand(req);
	}

}
