package lang.m2.wffjzc.diagram_default_root.part;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * @generated
 */
public class WffjzcCreationWizard extends Wizard implements INewWizard {

	/**
	 * @generated
	 */
	private IWorkbench workbench;

	/**
	 * @generated
	 */
	protected IStructuredSelection selection;

	/**
	 * @generated
	 */
	protected lang.m2.wffjzc.diagram_default_root.part.WffjzcCreationWizardPage diagramModelFilePage;

	/**
	 * @generated
	 */
	protected lang.m2.wffjzc.diagram_default_root.part.WffjzcCreationWizardPage domainModelFilePage;

	/**
	 * @generated
	 */
	protected Resource diagram;

	/**
	 * @generated
	 */
	private boolean openNewlyCreatedDiagramEditor = true;

	/**
	 * @generated
	 */
	public IWorkbench getWorkbench() {
		return workbench;
	}

	/**
	 * @generated
	 */
	public IStructuredSelection getSelection() {
		return selection;
	}

	/**
	 * @generated
	 */
	public final Resource getDiagram() {
		return diagram;
	}

	/**
	 * @generated
	 */
	public final boolean isOpenNewlyCreatedDiagramEditor() {
		return openNewlyCreatedDiagramEditor;
	}

	/**
	 * @generated
	 */
	public void setOpenNewlyCreatedDiagramEditor(
			boolean openNewlyCreatedDiagramEditor) {
		this.openNewlyCreatedDiagramEditor = openNewlyCreatedDiagramEditor;
	}

	/**
	 * @generated
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.workbench = workbench;
		this.selection = selection;
		setWindowTitle(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizardTitle);
		setDefaultPageImageDescriptor(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getBundledImageDescriptor("icons/wizban/NewWffjzcWizard.gif")); //$NON-NLS-1$
		setNeedsProgressMonitor(true);
	}

	/**
	 * @generated
	 */
	public void addPages() {
		diagramModelFilePage = new lang.m2.wffjzc.diagram_default_root.part.WffjzcCreationWizardPage(
				"DiagramModelFile", getSelection(), "wffjzc_default_root_diagram"); //$NON-NLS-1$ //$NON-NLS-2$
		diagramModelFilePage
				.setTitle(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizard_DiagramModelFilePageTitle);
		diagramModelFilePage
				.setDescription(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizard_DiagramModelFilePageDescription);
		addPage(diagramModelFilePage);

		domainModelFilePage = new lang.m2.wffjzc.diagram_default_root.part.WffjzcCreationWizardPage(
				"DomainModelFile", getSelection(), "wffjzc") { //$NON-NLS-1$ //$NON-NLS-2$

			public void setVisible(boolean visible) {
				if (visible) {
					String fileName = diagramModelFilePage.getFileName();
					fileName = fileName.substring(0, fileName.length()
							- ".wffjzc_default_root_diagram".length()); //$NON-NLS-1$
					setFileName(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorUtil
							.getUniqueFileName(getContainerFullPath(),
									fileName, "wffjzc")); //$NON-NLS-1$
				}
				super.setVisible(visible);
			}
		};
		domainModelFilePage
				.setTitle(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizard_DomainModelFilePageTitle);
		domainModelFilePage
				.setDescription(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizard_DomainModelFilePageDescription);
		addPage(domainModelFilePage);
	}

	/**
	 * @generated
	 */
	public boolean performFinish() {
		IRunnableWithProgress op = new WorkspaceModifyOperation(null) {

			protected void execute(IProgressMonitor monitor)
					throws CoreException, InterruptedException {
				diagram = lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorUtil
						.createDiagram(diagramModelFilePage.getURI(),
								domainModelFilePage.getURI(), monitor);
				if (isOpenNewlyCreatedDiagramEditor() && diagram != null) {
					try {
						lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorUtil
								.openDiagram(diagram);
					} catch (PartInitException e) {
						ErrorDialog
								.openError(
										getContainer().getShell(),
										lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizardOpenEditorError,
										null, e.getStatus());
					}
				}
			}
		};
		try {
			getContainer().run(false, true, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof CoreException) {
				ErrorDialog
						.openError(
								getContainer().getShell(),
								lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcCreationWizardCreationError,
								null, ((CoreException) e.getTargetException())
										.getStatus());
			} else {
				lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
						.getInstance()
						.logError(
								"Error creating diagram", e.getTargetException()); //$NON-NLS-1$
			}
			return false;
		}
		return diagram != null;
	}
}
