package lang.m2.wffjzc.diagram_default_root.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class WffjzcNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	 * @generated
	 */
	public WffjzcNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
