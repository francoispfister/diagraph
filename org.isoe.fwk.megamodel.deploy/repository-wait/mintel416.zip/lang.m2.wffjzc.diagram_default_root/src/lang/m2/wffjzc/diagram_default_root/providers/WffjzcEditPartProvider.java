package lang.m2.wffjzc.diagram_default_root.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class WffjzcEditPartProvider extends DefaultEditPartProvider {

	/**
	 * @generated
	 */
	public WffjzcEditPartProvider() {
		super(
				new lang.m2.wffjzc.diagram_default_root.edit.parts.WffjzcEditPartFactory(),
				lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry.TYPED_INSTANCE,
				lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.MODEL_ID);
	}

}
