package lang.m2.wffjzc.diagram_default_root.navigator;

import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class WffjzcNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem
				&& !isOwnView(((lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) element)
						.getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup) {
			lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup group = (lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup) element;
			return lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().getBundledImage(group.getIcon());
		}

		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) {
			lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem navigatorItem = (lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://wffjzc?Bbbb", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Bbbb_79); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://wffjzc?EClass0", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass0_1002); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2001); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2002); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2003); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2004); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2005); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2006); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2007); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?Ffff", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2008); //$NON-NLS-1$
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://wffjzc?EClass1", lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass1_2009); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null
				&& elementType != null
				&& lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
						.isKnownElementType(elementType)) {
			image = lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
					.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup) {
			lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup group = (lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) {
			lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem navigatorItem = (lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
				.getVisualID(view)) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.VISUAL_ID:
			return getBbbb_79Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffEditPart.VISUAL_ID:
			return getFfff_1001Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart.VISUAL_ID:
			return getEClass0_1002Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff2EditPart.VISUAL_ID:
			return getFfff_2001Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff3EditPart.VISUAL_ID:
			return getFfff_2002Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff4EditPart.VISUAL_ID:
			return getFfff_2003Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff5EditPart.VISUAL_ID:
			return getFfff_2004Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff6EditPart.VISUAL_ID:
			return getFfff_2005Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff7EditPart.VISUAL_ID:
			return getFfff_2006Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff8EditPart.VISUAL_ID:
			return getFfff_2007Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.Ffff9EditPart.VISUAL_ID:
			return getFfff_2008Text(view);
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1EditPart.VISUAL_ID:
			return getEClass1_2009Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getBbbb_79Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getFfff_1001Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffIdEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getEClass0_1002Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass0_1002,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0FooEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2001Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2001,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2002Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2002,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId3EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2003Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2003,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId4EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2004Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2004,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId5EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2005Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2005,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId6EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2006Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2006,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId7EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2007Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2007,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId8EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getFfff_2008Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2008,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId9EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getEClass1_2009Text(View view) {
		IParser parser = lang.m2.wffjzc.diagram_default_root.providers.WffjzcParserProvider
				.getParser(
						lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass1_2009,
						view.getElement() != null ? view.getElement() : view,
						lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
								.getType(lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1BarEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 4010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart.MODEL_ID
				.equals(lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
						.getModelID(view));
	}

}
