package lang.m2.wffjzc.diagram_default_root.providers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.modelingassistant.ModelingAssistantProvider;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

/**
 * @generated
 */
public class WffjzcModelingAssistantProvider extends ModelingAssistantProvider {

	/**
	 * @generated
	 */
	public List getTypesForPopupBar(IAdaptable host) {
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.BbbbEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_1001);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass0_1002);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.EClass1_2009);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFsEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2001);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs2EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2002);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs3EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2003);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs4EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2004);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs5EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2005);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs6EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2006);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs7EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2007);
			return types;
		}
		if (editPart instanceof lang.m2.wffjzc.diagram_default_root.edit.parts.FfffSubFs8EditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(1);
			types.add(lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes.Ffff_2008);
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForSource(IAdaptable target,
			IElementType relationshipType) {
		return selectExistingElement(target,
				getTypesForSource(target, relationshipType));
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForTarget(IAdaptable source,
			IElementType relationshipType) {
		return selectExistingElement(source,
				getTypesForTarget(source, relationshipType));
	}

	/**
	 * @generated
	 */
	protected EObject selectExistingElement(IAdaptable host, Collection types) {
		if (types.isEmpty()) {
			return null;
		}
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart == null) {
			return null;
		}
		Diagram diagram = (Diagram) editPart.getRoot().getContents().getModel();
		HashSet<EObject> elements = new HashSet<EObject>();
		for (Iterator<EObject> it = diagram.getElement().eAllContents(); it
				.hasNext();) {
			EObject element = it.next();
			if (isApplicableElement(element, types)) {
				elements.add(element);
			}
		}
		if (elements.isEmpty()) {
			return null;
		}
		return selectElement((EObject[]) elements.toArray(new EObject[elements
				.size()]));
	}

	/**
	 * @generated
	 */
	protected boolean isApplicableElement(EObject element, Collection types) {
		IElementType type = ElementTypeRegistry.getInstance().getElementType(
				element);
		return types.contains(type);
	}

	/**
	 * @generated
	 */
	protected EObject selectElement(EObject[] elements) {
		Shell shell = Display.getCurrent().getActiveShell();
		ILabelProvider labelProvider = new AdapterFactoryLabelProvider(
				lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
						.getInstance().getItemProvidersAdapterFactory());
		ElementListSelectionDialog dialog = new ElementListSelectionDialog(
				shell, labelProvider);
		dialog.setMessage(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcModelingAssistantProviderMessage);
		dialog.setTitle(lang.m2.wffjzc.diagram_default_root.part.Messages.WffjzcModelingAssistantProviderTitle);
		dialog.setMultipleSelection(false);
		dialog.setElements(elements);
		EObject selected = null;
		if (dialog.open() == Window.OK) {
			selected = (EObject) dialog.getFirstResult();
		}
		return selected;
	}
}
