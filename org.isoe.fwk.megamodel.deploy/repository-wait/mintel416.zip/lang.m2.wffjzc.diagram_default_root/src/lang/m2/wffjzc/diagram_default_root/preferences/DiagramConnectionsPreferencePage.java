package lang.m2.wffjzc.diagram_default_root.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(lang.m2.wffjzc.diagram_default_root.part.WffjzcDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
