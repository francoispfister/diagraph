package lang.m2.wffjzc.diagram_default_root.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class WffjzcNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 5010;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) {
			lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem item = (lang.m2.wffjzc.diagram_default_root.navigator.WffjzcNavigatorItem) element;
			return lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
