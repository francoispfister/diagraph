package lang.m2.wffjzc.diagram_default_root.providers;

import lang.m2.wffjzc.WffjzcPackage;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class WffjzcParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser ffffId_4009Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4009Parser() {
		if (ffffId_4009Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4009Parser = parser;
		}
		return ffffId_4009Parser;
	}

	/**
	 * @generated
	 */
	private IParser eClass0Foo_4011Parser;

	/**
	 * @generated
	 */
	private IParser getEClass0Foo_4011Parser() {
		if (eClass0Foo_4011Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getEClass0_Foo() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			eClass0Foo_4011Parser = parser;
		}
		return eClass0Foo_4011Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4008Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4008Parser() {
		if (ffffId_4008Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4008Parser = parser;
		}
		return ffffId_4008Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4007Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4007Parser() {
		if (ffffId_4007Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4007Parser = parser;
		}
		return ffffId_4007Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4006Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4006Parser() {
		if (ffffId_4006Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4006Parser = parser;
		}
		return ffffId_4006Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4005Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4005Parser() {
		if (ffffId_4005Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4005Parser = parser;
		}
		return ffffId_4005Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4004Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4004Parser() {
		if (ffffId_4004Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4004Parser = parser;
		}
		return ffffId_4004Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4003Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4003Parser() {
		if (ffffId_4003Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4003Parser = parser;
		}
		return ffffId_4003Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4002Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4002Parser() {
		if (ffffId_4002Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4002Parser = parser;
		}
		return ffffId_4002Parser;
	}

	/**
	 * @generated
	 */
	private IParser ffffId_4001Parser;

	/**
	 * @generated
	 */
	private IParser getFfffId_4001Parser() {
		if (ffffId_4001Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getFfff_Id() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			ffffId_4001Parser = parser;
		}
		return ffffId_4001Parser;
	}

	/**
	 * @generated
	 */
	private IParser eClass1Bar_4010Parser;

	/**
	 * @generated
	 */
	private IParser getEClass1Bar_4010Parser() {
		if (eClass1Bar_4010Parser == null) {
			EAttribute[] features = new EAttribute[] { WffjzcPackage.eINSTANCE
					.getEClass1_Bar() };
			lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser parser = new lang.m2.wffjzc.diagram_default_root.parsers.MessageFormatParser(
					features);
			eClass1Bar_4010Parser = parser;
		}
		return eClass1Bar_4010Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffIdEditPart.VISUAL_ID:
			return getFfffId_4009Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass0FooEditPart.VISUAL_ID:
			return getEClass0Foo_4011Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId2EditPart.VISUAL_ID:
			return getFfffId_4008Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId3EditPart.VISUAL_ID:
			return getFfffId_4007Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId4EditPart.VISUAL_ID:
			return getFfffId_4006Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId5EditPart.VISUAL_ID:
			return getFfffId_4005Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId6EditPart.VISUAL_ID:
			return getFfffId_4004Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId7EditPart.VISUAL_ID:
			return getFfffId_4003Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId8EditPart.VISUAL_ID:
			return getFfffId_4002Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.FfffId9EditPart.VISUAL_ID:
			return getFfffId_4001Parser();
		case lang.m2.wffjzc.diagram_default_root.edit.parts.EClass1BarEditPart.VISUAL_ID:
			return getEClass1Bar_4010Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(lang.m2.wffjzc.diagram_default_root.part.WffjzcVisualIDRegistry
					.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (lang.m2.wffjzc.diagram_default_root.providers.WffjzcElementTypes
					.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
