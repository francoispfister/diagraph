/**
 */
package lang.m2.simpleworld;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Thing</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.simpleworld.Thing#getId <em>Id</em>}</li>
 *   <li>{@link lang.m2.simpleworld.Thing#getRelations <em>Relations</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.simpleworld.SimpleworldPackage#getThing()
 * @model annotation="diagraph node='null' nav:vwthing='null'"
 *        annotation="diagraph node='null' view\075vwthing='null' pov='null'"
 * @generated
 */
public interface Thing extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(int)
	 * @see lang.m2.simpleworld.SimpleworldPackage#getThing_Id()
	 * @model
	 * @generated
	 */
	int getId();

	/**
	 * Sets the value of the '{@link lang.m2.simpleworld.Thing#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(int value);

	/**
	 * Returns the value of the '<em><b>Relations</b></em>' containment reference list.
	 * The list contents are of type {@link lang.m2.simpleworld.RelatedTo}.
	 * It is bidirectional and its opposite is '{@link lang.m2.simpleworld.RelatedTo#getFromThing <em>From Thing</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Relations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relations</em>' containment reference list.
	 * @see lang.m2.simpleworld.SimpleworldPackage#getThing_Relations()
	 * @see lang.m2.simpleworld.RelatedTo#getFromThing
	 * @model opposite="fromThing" containment="true"
	 * @generated
	 */
	EList<RelatedTo> getRelations();

} // Thing
