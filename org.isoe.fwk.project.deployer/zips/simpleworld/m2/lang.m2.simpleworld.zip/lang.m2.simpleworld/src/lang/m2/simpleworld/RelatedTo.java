/**
 */
package lang.m2.simpleworld;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Related To</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.simpleworld.RelatedTo#getFromThing <em>From Thing</em>}</li>
 *   <li>{@link lang.m2.simpleworld.RelatedTo#getToThing <em>To Thing</em>}</li>
 *   <li>{@link lang.m2.simpleworld.RelatedTo#getSince <em>Since</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.simpleworld.SimpleworldPackage#getRelatedTo()
 * @model annotation="diagraph link='null' cont\075Thing.relations='null' lsrc\075fromThing='null' ltrg\075toThing='null'"
 *        annotation="diagraph node='null' view\075vwthing='null' label\075since='null'"
 * @generated
 */
public interface RelatedTo extends NamedElement {
	/**
	 * Returns the value of the '<em><b>From Thing</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link lang.m2.simpleworld.Thing#getRelations <em>Relations</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From Thing</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From Thing</em>' container reference.
	 * @see #setFromThing(Thing)
	 * @see lang.m2.simpleworld.SimpleworldPackage#getRelatedTo_FromThing()
	 * @see lang.m2.simpleworld.Thing#getRelations
	 * @model opposite="relations" transient="false"
	 * @generated
	 */
	Thing getFromThing();

	/**
	 * Sets the value of the '{@link lang.m2.simpleworld.RelatedTo#getFromThing <em>From Thing</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From Thing</em>' container reference.
	 * @see #getFromThing()
	 * @generated
	 */
	void setFromThing(Thing value);

	/**
	 * Returns the value of the '<em><b>To Thing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To Thing</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To Thing</em>' reference.
	 * @see #setToThing(Thing)
	 * @see lang.m2.simpleworld.SimpleworldPackage#getRelatedTo_ToThing()
	 * @model
	 * @generated
	 */
	Thing getToThing();

	/**
	 * Sets the value of the '{@link lang.m2.simpleworld.RelatedTo#getToThing <em>To Thing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To Thing</em>' reference.
	 * @see #getToThing()
	 * @generated
	 */
	void setToThing(Thing value);

	/**
	 * Returns the value of the '<em><b>Since</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Since</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Since</em>' attribute.
	 * @see #setSince(String)
	 * @see lang.m2.simpleworld.SimpleworldPackage#getRelatedTo_Since()
	 * @model
	 * @generated
	 */
	String getSince();

	/**
	 * Sets the value of the '{@link lang.m2.simpleworld.RelatedTo#getSince <em>Since</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Since</em>' attribute.
	 * @see #getSince()
	 * @generated
	 */
	void setSince(String value);

} // RelatedTo
