/**
 */
package lang.m2.simpleworld.impl;

import lang.m2.simpleworld.RelatedTo;
import lang.m2.simpleworld.SimpleworldPackage;
import lang.m2.simpleworld.Thing;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Related To</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link lang.m2.simpleworld.impl.RelatedToImpl#getFromThing <em>From Thing</em>}</li>
 *   <li>{@link lang.m2.simpleworld.impl.RelatedToImpl#getToThing <em>To Thing</em>}</li>
 *   <li>{@link lang.m2.simpleworld.impl.RelatedToImpl#getSince <em>Since</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RelatedToImpl extends NamedElementImpl implements RelatedTo {
	/**
	 * The cached value of the '{@link #getToThing() <em>To Thing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToThing()
	 * @generated
	 * @ordered
	 */
	protected Thing toThing;

	/**
	 * The default value of the '{@link #getSince() <em>Since</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSince()
	 * @generated
	 * @ordered
	 */
	protected static final String SINCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSince() <em>Since</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSince()
	 * @generated
	 * @ordered
	 */
	protected String since = SINCE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RelatedToImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SimpleworldPackage.Literals.RELATED_TO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thing getFromThing() {
		if (eContainerFeatureID() != SimpleworldPackage.RELATED_TO__FROM_THING) return null;
		return (Thing)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFromThing(Thing newFromThing, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newFromThing, SimpleworldPackage.RELATED_TO__FROM_THING, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFromThing(Thing newFromThing) {
		if (newFromThing != eInternalContainer() || (eContainerFeatureID() != SimpleworldPackage.RELATED_TO__FROM_THING && newFromThing != null)) {
			if (EcoreUtil.isAncestor(this, newFromThing))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newFromThing != null)
				msgs = ((InternalEObject)newFromThing).eInverseAdd(this, SimpleworldPackage.THING__RELATIONS, Thing.class, msgs);
			msgs = basicSetFromThing(newFromThing, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SimpleworldPackage.RELATED_TO__FROM_THING, newFromThing, newFromThing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thing getToThing() {
		if (toThing != null && toThing.eIsProxy()) {
			InternalEObject oldToThing = (InternalEObject)toThing;
			toThing = (Thing)eResolveProxy(oldToThing);
			if (toThing != oldToThing) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SimpleworldPackage.RELATED_TO__TO_THING, oldToThing, toThing));
			}
		}
		return toThing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thing basicGetToThing() {
		return toThing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setToThing(Thing newToThing) {
		Thing oldToThing = toThing;
		toThing = newToThing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SimpleworldPackage.RELATED_TO__TO_THING, oldToThing, toThing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSince() {
		return since;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSince(String newSince) {
		String oldSince = since;
		since = newSince;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SimpleworldPackage.RELATED_TO__SINCE, oldSince, since));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetFromThing((Thing)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				return basicSetFromThing(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				return eInternalContainer().eInverseRemove(this, SimpleworldPackage.THING__RELATIONS, Thing.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				return getFromThing();
			case SimpleworldPackage.RELATED_TO__TO_THING:
				if (resolve) return getToThing();
				return basicGetToThing();
			case SimpleworldPackage.RELATED_TO__SINCE:
				return getSince();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				setFromThing((Thing)newValue);
				return;
			case SimpleworldPackage.RELATED_TO__TO_THING:
				setToThing((Thing)newValue);
				return;
			case SimpleworldPackage.RELATED_TO__SINCE:
				setSince((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				setFromThing((Thing)null);
				return;
			case SimpleworldPackage.RELATED_TO__TO_THING:
				setToThing((Thing)null);
				return;
			case SimpleworldPackage.RELATED_TO__SINCE:
				setSince(SINCE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SimpleworldPackage.RELATED_TO__FROM_THING:
				return getFromThing() != null;
			case SimpleworldPackage.RELATED_TO__TO_THING:
				return toThing != null;
			case SimpleworldPackage.RELATED_TO__SINCE:
				return SINCE_EDEFAULT == null ? since != null : !SINCE_EDEFAULT.equals(since);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (since: ");
		result.append(since);
		result.append(')');
		return result.toString();
	}

} //RelatedToImpl
