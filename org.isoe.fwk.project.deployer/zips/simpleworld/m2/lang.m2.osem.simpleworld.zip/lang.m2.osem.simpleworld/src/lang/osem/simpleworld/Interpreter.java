/**
 * Copyright (c) 2014 Laboratoire de Genie Informatique et Ingenierie de Production - Ecole des Mines d'Ales
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Francois Pfister (ISOE-LGI2P) - initial API and implementation
 */
package lang.osem.simpleworld;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import lang.m2.simpleworld.RelatedTo;
import lang.m2.simpleworld.SimpleworldFactory;
import lang.m2.simpleworld.SimpleworldPackage;
import lang.m2.simpleworld.Thing;
import lang.m2.simpleworld.World;

import org.eclipse.emf.common.EMFPlugin;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.isoe.extensionpoint.diagraph.IDiagraphControler;
import org.isoe.extensionpoint.modelrunner.ModelInterpreter;

/**
 *
 * @author fpfister
 *
 */
public class Interpreter implements ModelInterpreter {

	private Resource resource;
	private String resourcename;
	private String folder;
	private String plugin;
    private URI uri;
	private String language = SimpleworldPackage.eNAME;


	@Override
	public String getLanguage() {
		return language;
	}

	@Override
	public String getLocation() {
		return "platform:/resource/"+plugin+"/"+folder+"/"+resourcename+"."+language;
	}

	@Override
	public void setFolder(String folder) {
		this.folder = folder;
	}

    @Override
	public String getFolder() {
		return folder;
	}

	@Override
	public void setPlugin(String plugin) {
		this.plugin = plugin;
	}

	@Override
	public void setResourceName(String resourceName) {
		this.resourcename = resourceName;
	}


	@Override
	public String getResourcename() {
		return resourcename;
	}

	@Override
	public String getPlugin() {
		return plugin;
	}

	@Override
	public Resource getResource() {
		return resource;
	}

	@Override
	public URI getUri() {
		return uri;
	}

	public static void main(String[] a) {
		Interpreter loader = new Interpreter();
		loader.load();
		loader.run();
	}


	public void createAndSaveSample() {
		World sample = createSampleWorld();
		try {
			save(sample, getResourceURI_(resourcename + "_sample"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private URI getResourceURI_(String rname) {
		if (!EMFPlugin.IS_ECLIPSE_RUNNING)
			return getFileURI_(rname);
		else
			return getURI_(rname);
	}

	private URI getURI_(String rname) {
		URI result = URI.createURI("platform:/resource/" + plugin + "/"
				+ folder + "/" + rname + "." + SimpleworldPackage.eNAME);
		return result;
	}

	private URI getFileURI_(String rname) {
		String filepath = folder + "/" + rname + "." + SimpleworldPackage.eNAME;
		File file = new File(filepath);
		URI uri = URI.createFileURI(file.getAbsolutePath());
		return uri;
	}

	public World createSampleWorld() {
		World world = SimpleworldFactory.eINSTANCE.createWorld();


		Thing sc = SimpleworldFactory.eINSTANCE.createThing();
		sc.setName("c");
		world.getThings().add(sc);
		sc.setId(1);
		sc.setName("thing a");


		Thing sb = SimpleworldFactory.eINSTANCE.createThing();
		sb.setId(2);
		sb.setName("thing b");
		world.getThings().add(sb);


		Thing sa = SimpleworldFactory.eINSTANCE.createThing();
		sa.setId(2);
		sa.setName("thing b");
		world.getThings().add(sa);

		RelatedTo tbc = SimpleworldFactory.eINSTANCE.createRelatedTo();
		tbc.setFromThing(sb);
		tbc.setToThing(sc);
		tbc.setName("j");
		tbc.setSince("k");


		RelatedTo tab = SimpleworldFactory.eINSTANCE.createRelatedTo();
		tbc.setFromThing(sa);
		tbc.setToThing(sb);
		tbc.setName("t");
		tbc.setSince("v");

		return world;
	}

	public World createSampleWorld_() {
		World world = SimpleworldFactory.eINSTANCE.createWorld();
		return world;
	}

	private Resource save(EObject toSave, URI uri) throws IOException {
		new File(uri.toFileString()).delete();
		Resource resource = new XMIResourceFactoryImpl().createResource(uri);
		resource.getContents().add(toSave);
		Map<String, String> options = new HashMap<String, String>();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(options);
		return resource;
	}

	@Override
	public void load() {
		this.uri = getResourceURI_(resourcename);
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet
				.getResourceFactoryRegistry()
				.getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION,
						new XMIResourceFactoryImpl());

		resourceSet.getPackageRegistry().put(SimpleworldPackage.eNS_URI,
				SimpleworldPackage.eINSTANCE);
		this.resource = resourceSet.getResource(uri, true);
		System.out.println("Loaded " + resource.getURI().toString());
	}

	private void printWorld(World world) {


		EList<Thing> things = world.getThings();
		for (Thing thing : things) {
			System.out.println(thing.getName());
			EList<RelatedTo> relations = thing.getRelations();
			for (RelatedTo relation : relations) {
				System.out.println(relation.getSince() + " - "
						+ relation.getFromThing().getName() + " -> "
						+ relation.getToThing().getName());
			}

		}
	}

	@Override
	public void run() {
		for (EObject eObject : resource.getContents()) {
			Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);
			if (diagnostic.getSeverity() != Diagnostic.OK) {
				printDiagnostic(diagnostic, "");
			}
		}
		printWorld((World) resource.getContents().get(0));
	}

	protected static void printDiagnostic(Diagnostic diagnostic, String indent) {
		System.out.print(indent);
		System.out.println(diagnostic.getMessage());
		for (Diagnostic child : diagnostic.getChildren()) {
			printDiagnostic(child, indent + "  ");
		}
	}

	@Override
	public void setControler(IDiagraphControler controler) {

	}

	@Override
	public boolean isStub() {
		return false;
	}

	@Override
	public boolean isQualified() {
		return true;
	}

	@Override
	public void setSilent(boolean value) {

	}


}
