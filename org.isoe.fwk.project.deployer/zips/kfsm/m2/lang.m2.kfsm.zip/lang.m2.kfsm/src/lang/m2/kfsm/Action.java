/**
 */
package lang.m2.kfsm;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.kfsm.Action#getId <em>Id</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.kfsm.KfsmPackage#getAction()
 * @model annotation="diagraph node='null' label\075id='null'"
 * @generated
 */
public interface Action extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see lang.m2.kfsm.KfsmPackage#getAction_Id()
	 * @model dataType="lang.m2.kfsm.String"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link lang.m2.kfsm.Action#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

} // Action
