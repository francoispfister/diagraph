/**
 */
package lang.m2.kfsm;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link lang.m2.kfsm.State#getOwningFSM <em>Owning FSM</em>}</li>
 *   <li>{@link lang.m2.kfsm.State#getName <em>Name</em>}</li>
 *   <li>{@link lang.m2.kfsm.State#getOutgoingTransition <em>Outgoing Transition</em>}</li>
 *   <li>{@link lang.m2.kfsm.State#getIncomingTransition <em>Incoming Transition</em>}</li>
 *   <li>{@link lang.m2.kfsm.State#getS_action <em>Saction</em>}</li>
 * </ul>
 * </p>
 *
 * @see lang.m2.kfsm.KfsmPackage#getState()
 * @model annotation="diagraph node='null' label\075name='null' cref\075s_action='null'"
 * @generated
 */
public interface State extends EObject {
	/**
	 * Returns the value of the '<em><b>Owning FSM</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link lang.m2.kfsm.FSM#getOwnedState <em>Owned State</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owning FSM</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owning FSM</em>' container reference.
	 * @see #setOwningFSM(FSM)
	 * @see lang.m2.kfsm.KfsmPackage#getState_OwningFSM()
	 * @see lang.m2.kfsm.FSM#getOwnedState
	 * @model opposite="ownedState" required="true" transient="false"
	 * @generated
	 */
	FSM getOwningFSM();

	/**
	 * Sets the value of the '{@link lang.m2.kfsm.State#getOwningFSM <em>Owning FSM</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owning FSM</em>' container reference.
	 * @see #getOwningFSM()
	 * @generated
	 */
	void setOwningFSM(FSM value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see lang.m2.kfsm.KfsmPackage#getState_Name()
	 * @model dataType="lang.m2.kfsm.String"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link lang.m2.kfsm.State#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Outgoing Transition</b></em>' containment reference list.
	 * The list contents are of type {@link lang.m2.kfsm.Transition}.
	 * It is bidirectional and its opposite is '{@link lang.m2.kfsm.Transition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoing Transition</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoing Transition</em>' containment reference list.
	 * @see lang.m2.kfsm.KfsmPackage#getState_OutgoingTransition()
	 * @see lang.m2.kfsm.Transition#getSource
	 * @model opposite="source" containment="true"
	 * @generated
	 */
	EList<Transition> getOutgoingTransition();

	/**
	 * Returns the value of the '<em><b>Incoming Transition</b></em>' reference list.
	 * The list contents are of type {@link lang.m2.kfsm.Transition}.
	 * It is bidirectional and its opposite is '{@link lang.m2.kfsm.Transition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incoming Transition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incoming Transition</em>' reference list.
	 * @see lang.m2.kfsm.KfsmPackage#getState_IncomingTransition()
	 * @see lang.m2.kfsm.Transition#getTarget
	 * @model opposite="target"
	 * @generated
	 */
	EList<Transition> getIncomingTransition();

	/**
	 * Returns the value of the '<em><b>Saction</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Saction</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Saction</em>' containment reference.
	 * @see #setS_action(Action)
	 * @see lang.m2.kfsm.KfsmPackage#getState_S_action()
	 * @model containment="true"
	 * @generated
	 */
	Action getS_action();

	/**
	 * Sets the value of the '{@link lang.m2.kfsm.State#getS_action <em>Saction</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Saction</em>' containment reference.
	 * @see #getS_action()
	 * @generated
	 */
	void setS_action(Action value);

} // State
