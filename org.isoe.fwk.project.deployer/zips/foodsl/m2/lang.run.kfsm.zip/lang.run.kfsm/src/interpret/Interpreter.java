/**
 * Copyright (c) 2014 Laboratoire de Genie Informatique et Ingenierie de Production - Ecole des Mines d'Ales
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Francois Pfister (ISOE-LGI2P) - initial API and implementation
 */
package interpret;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import lang.m2.kfsm.FSM;
import lang.m2.kfsm.KfsmFactory;
import lang.m2.kfsm.KfsmPackage;
import lang.m2.kfsm.State;
import lang.m2.kfsm.Transition;

import org.eclipse.emf.common.EMFPlugin;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.isoe.extensionpoint.diagraph.IDiagraphControler;
import org.isoe.extensionpoint.interpreter.ModelInterpreter;

/**
 * 
 * @author fpfister
 * 
 */
public class Interpreter implements ModelInterpreter {
	// FP140317


	private Resource resource;
	private String resourcename;
	private String folder;
	private String plugin;
    private URI uri;
	private String language = KfsmPackage.eNAME;
	
	
	@Override
	public String getLanguage() {
		return language;
	}
	
	@Override
	public String getLocation() {
		return "platform:/resource/"+plugin+"/"+folder+"/"+resourcename+"."+language;
	}	
	
	@Override
	public void setFolder(String folder) {
		this.folder = folder;
	}
	
    @Override
	public String getFolder() {
		return folder;
	}

	@Override
	public void setPlugin(String plugin) {
		this.plugin = plugin;	
	}

	@Override
	public void setResourceName(String resourceName) {
		this.resourcename = resourceName;
	}
	

	@Override
	public String getResourcename() {
		return resourcename;
	}

	@Override
	public String getPlugin() {
		return plugin;
	}

	@Override
	public Resource getResource() {
		return resource;
	}

	@Override
	public URI getUri() {
		return uri;
	}

	public static void main(String[] a) {
		Interpreter loader = new Interpreter();
		loader.load();
		loader.run();
	}


	public void createAndSaveSample() {
		FSM sample = createSampleFSM();
		try {
			save(sample, getResourceURI_(resourcename + "_sample"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private URI getResourceURI_(String rname) {
		if (!EMFPlugin.IS_ECLIPSE_RUNNING)
			return getFileURI_(rname);
		else
			return getURI_(rname);
	}

	private URI getURI_(String rname) {
		URI result = URI.createURI("platform:/resource/" + plugin + "/"
				+ folder + "/" + rname + "." + KfsmPackage.eNAME);
		return result;
	}

	private URI getFileURI_(String rname) {
		String filepath = folder + "/" + rname + "." + KfsmPackage.eNAME;
		File file = new File(filepath);
		URI uri = URI.createFileURI(file.getAbsolutePath());
		return uri;
	}

	public FSM createSampleFSM() {
		FSM fsm = KfsmFactory.eINSTANCE.createFSM();
		State sc = KfsmFactory.eINSTANCE.createState();
		sc.setName("c");
		fsm.getOwnedState().add(sc);
		sc.setOwningFSM(fsm);
		fsm.getFinalState().add(sc);

		State sb = KfsmFactory.eINSTANCE.createState();
		sb.setName("b");
		fsm.getOwnedState().add(sb);
		sb.setOwningFSM(fsm);

		State sa = KfsmFactory.eINSTANCE.createState();
		sa.setName("a");
		fsm.getOwnedState().add(sa);
		// sa.setOwningFSM(root);
		fsm.setInitialState(sa);

		Transition tbc = KfsmFactory.eINSTANCE.createTransition();
		tbc.setInput("j");
		tbc.setOutput("k");
		tbc.setSource(sb);
		tbc.setTarget(sc);

		Transition tab = KfsmFactory.eINSTANCE.createTransition();
		tab.setInput("t");
		tab.setOutput("v");
		tab.setSource(sa);
		tab.setTarget(sb);
		// sa.getOutgoingTransition().add(e);
		return fsm;
	}

	public FSM createSampleFSM_() {
		FSM fsm = KfsmFactory.eINSTANCE.createFSM();
		return fsm;
	}

	private Resource save(EObject toSave, URI uri) throws IOException {
		new File(uri.toFileString()).delete();
		Resource resource = new XMIResourceFactoryImpl().createResource(uri);
		resource.getContents().add(toSave);
		Map<String, String> options = new HashMap<String, String>();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(options);
		return resource;
	}

	@Override
	public void load() {
		this.uri = getResourceURI_(resourcename);
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet
				.getResourceFactoryRegistry()
				.getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION,
						new XMIResourceFactoryImpl());

		resourceSet.getPackageRegistry().put(KfsmPackage.eNS_URI,
				KfsmPackage.eINSTANCE);
		this.resource = resourceSet.getResource(uri, true);
		System.out.println("Loaded " + resource.getURI().toString());
	}

	private void printFsm(FSM fsm) {
		EList<State> states = fsm.getOwnedState();
		for (State state : states) {
			System.out.println(state.getName());
			EList<Transition> transitions = state.getOutgoingTransition();
			for (Transition transition : transitions) {
				System.out.println(transition.getInput() + " - "
						+ transition.getOutput() + " -> "
						+ transition.getTarget().getName());
			}

		}
	}

	@Override
	public void run() {
		for (EObject eObject : resource.getContents()) {
			Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);
			if (diagnostic.getSeverity() != Diagnostic.OK) {
				printDiagnostic(diagnostic, "");
			}
		}
		printFsm((FSM) resource.getContents().get(0));
	}

	protected static void printDiagnostic(Diagnostic diagnostic, String indent) {
		System.out.print(indent);
		System.out.println(diagnostic.getMessage());
		for (Diagnostic child : diagnostic.getChildren()) {
			printDiagnostic(child, indent + "  ");
		}
	}

	@Override
	public void setControler(IDiagraphControler controler) {
		
	}

	@Override
	public boolean isStub() {
		return false;
	}

	@Override
	public boolean isQualified() {
		return true;
	}

	@Override
	public void setSilent(boolean value) {
		
	}


}
